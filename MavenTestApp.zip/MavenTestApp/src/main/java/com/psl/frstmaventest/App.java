package com.psl.frstmaventest;
import org.slf4j.*;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       Logger logger = LoggerFactory.getLogger(App.class);
	   logger.info("Hello world");
    }
}
